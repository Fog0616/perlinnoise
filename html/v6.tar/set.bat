
echo Need python3
python -m http.server
open  http://localhost:8000/v6.html
start http://localhost:8000/v6.html
open  http://localhost:8000/v6.html